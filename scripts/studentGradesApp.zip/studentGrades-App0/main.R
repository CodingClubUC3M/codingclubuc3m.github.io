#packages
library(DT)
library(shiny)
library(readr)
library(knitr)
library(vioplot)

#run the app if the App code is at the working directory
runApp()
